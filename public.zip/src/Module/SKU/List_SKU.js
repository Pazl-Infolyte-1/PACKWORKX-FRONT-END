import React, { useState } from 'react'
import './Style.css'
import box_open from './images/box_open.svg'
import takeout_dining from './images/takeout_dining.svg'
import setting_input from './images/settings_input_composite.svg'
import checkroom from './images/checkroom.svg'
import action from './images/more_vert.svg'
import arrowleft from './images/keyboard_double_arrow_left.svg'
import arrowright from './images/keyboard_double_arrow_right.svg'

function Sku_managment_dasboard() {
  const [skuType, setSkuType] = useState('')
  const [client, setClient] = useState('')
  const [searchSKU, setSearchSKU] = useState('')

  return (
    <>
      <div className="container" style={{ height: '100vh', backgroundColor: '#f8f8f8' }}>
        <div className="header">
          <h1 id="sku" style={{ fontSize: '42px' }}>
            SKU
          </h1>

          <span style={{ marginLeft: '200px' }}>
            <h2 className="text">Total SKU Count: 475</h2>
          </span>

          <div className="buttons">
            <button className="btn">Add SKU</button>
            <button className="btn">Bulk Upload</button>
            <button className="btn">Export to Excel</button>
          </div>
        </div>

        <div className="cards">
          <div id="Corrugated_Box" className="box" style={{ backgroundColor: '#286eb1' }}>
            <div style={{ marginLeft: '20px' }}>
              <h2 style={{ fontSize: '25px', fontWeight: 'bold' }}>
                Corrugated Box
                <span>
                  <h2 style={{ textAlign: 'center' }}>10000</h2>
                </span>
              </h2>
              <div
                style={{
                  height: '30%',
                  width: '30%',
                  display: 'flex',
                  justifyContent: 'flex-end',
                  alignItems: 'center',
                  marginRight: '10px',
                }}
              >
                <div
                  className="background"
                  style={{
                    height: '60px',
                    width: '60px',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: '#2e2d6d',
                  }}
                >
                  <img src={box_open} alt="" style={{ height: '50px', width: '50px' }} />
                </div>
              </div>
            </div>
          </div>

          <div id="Die_Cut_Box" className="box" style={{ backgroundColor: '#ffeeaa' }}>
            <div style={{ marginLeft: '20px' }}>
              <h2 style={{ fontSize: '25px', fontWeight: 'bold' }}>
                Die Cut Box
                <span>
                  <h2 style={{ textAlign: 'center' }}>200</h2>
                </span>
              </h2>
              <div
                style={{
                  height: '30%',
                  width: '30%',
                  display: 'flex',
                  justifyContent: 'flex-end',
                  alignItems: 'center',
                  marginRight: '10px',
                }}
              >
                <div
                  className="background"
                  style={{
                    height: '60px',
                    width: '60px',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: '#ffcc00',
                  }}
                >
                  <img src={takeout_dining} alt="" style={{ height: '50px', width: '50px' }} />
                </div>
              </div>
            </div>
          </div>

          <div id="Composite Item" className="box" style={{ backgroundColor: '#aad3ff' }}>
            <div style={{ marginLeft: '20px' }}>
              <h2 style={{ fontSize: '25px', fontWeight: 'bold' }}>
                Composite Item
                <span>
                  <h2 style={{ textAlign: 'center' }}>75</h2>
                </span>
              </h2>
              <div
                style={{
                  height: '30%',
                  width: '30%',
                  display: 'flex',
                  justifyContent: 'flex-end',
                  alignItems: 'center',
                  marginRight: '10px',
                }}
              >
                <div
                  className="background"
                  style={{
                    height: '60px',
                    width: '60px',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: '#007aff',
                  }}
                >
                  <img src={setting_input} alt="" style={{ height: '50px', width: '50px' }} />
                </div>
              </div>
            </div>
          </div>

          <div id="Custom Item" className="box" style={{ backgroundColor: '#c3f2cb' }}>
            <div style={{ marginLeft: '20px' }}>
              <h2 style={{ fontSize: '25px', fontWeight: 'bold' }}>
                Custom Item
                <span>
                  <h2 style={{ textAlign: 'center' }}>50</h2>
                </span>
              </h2>
              <div
                style={{
                  height: '30%',
                  width: '30%',
                  display: 'flex',
                  justifyContent: 'flex-end',
                  alignItems: 'center',
                  marginRight: '10px',
                }}
              >
                <div
                  className="background"
                  style={{
                    height: '60px',
                    width: '60px',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: '#4cd964',
                  }}
                >
                  <img src={checkroom} alt="" style={{ height: '50px', width: '50px' }} />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="input">
          <div
            style={{
              display: 'flex',
              justifyContent: 'left',
              alignItems: 'center',
            }}
          >
            <input
              type="text"
              placeholder="Search SKU"
              value={searchSKU}
              onChange={(e) => setSearchSKU(e.target.value)}
            />
          </div>

          <div
            className="options"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'left',
              gap: '30px',
            }}
          >
            <select
              name="sku_type"
              id="types"
              value={skuType}
              onChange={(e) => setSkuType(e.target.value)}
              style={{ width: '150px' }}
            >
              <option value="" disabled selected>
                SKU Type
              </option>
              <option value="type1">Type 1</option>
              <option value="type2">Type 2</option>
              <option value="type3">Type 3</option>
            </select>

            <select
              name="client"
              id="client"
              value={client}
              onChange={(e) => setClient(e.target.value)}
              style={{ width: '150px' }}
            >
              <option value="" disabled selected>
                Client
              </option>
              <option value="client1">Client 1</option>
              <option value="client2">Client 2</option>
              <option value="client3">Client 3</option>
            </select>
          </div>
        </div>

        <div style={{ padding: '20px' }}>
          <table table style={{ borderCollapse: 'collapse', width: '100%' }}>
            <thead
              style={{
                backgroundColor: '#21338e',
                color: '#ffffff',
                height: '65px',
              }}
            >
              <tr>
                <th>SKU Name</th>
                <th style={{ padding: '10px', fontWeight: '700', fontSize: '20px' }}>
                  Created Date
                </th>
                <th style={{ padding: '10px', fontWeight: '700', fontSize: '20px' }}>
                  Modified Date
                </th>
                <th style={{ padding: '10px', fontWeight: '700', fontSize: '20px' }}>Sku Type</th>
                <th style={{ padding: '10px', fontWeight: '700', fontSize: '20px' }}>Client</th>
                <th style={{ padding: '10px', fontWeight: '700', fontSize: '20px' }}>Dimensions</th>
                <th style={{ padding: '10px', fontWeight: '700', fontSize: '20px' }}>Deckle</th>
                <th style={{ padding: '10px', fontWeight: '700', fontSize: '20px' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr style={{ backgroundColor: '#ffffff' }}>
                <td
                  style={{
                    borderBottom: '1px solid #ced4dd',
                    padding: '10px',
                    textAlign: 'center',
                    fontSize: '18px',
                  }}
                >
                  Box
                </td>
                <td
                  style={{
                    borderBottom: '1px solid #ced4dd',
                    padding: '10px',
                    textAlign: 'center',
                    fontSize: '18px',
                  }}
                >
                  2022-01-01
                </td>
                <td
                  style={{
                    borderBottom: '1px solid #ced4dd',
                    padding: '10px',
                    textAlign: 'center',
                    fontSize: '18px',
                  }}
                >
                  2022-01-01
                </td>
                <td
                  style={{
                    borderBottom: '1px solid #ced4dd',
                    padding: '10px',
                    textAlign: 'center',
                    fontSize: '18px',
                  }}
                >
                  Box
                </td>
                <td
                  style={{
                    borderBottom: '1px solid #ced4dd',
                    padding: '10px',
                    textAlign: 'center',
                    fontSize: '18px',
                  }}
                >
                  Client 1
                </td>
                <td
                  style={{
                    borderBottom: '1px solid #ced4dd',
                    padding: '10px',
                    textAlign: 'center',
                    fontSize: '18px',
                  }}
                >
                  10x10x10
                </td>
                <td
                  style={{
                    borderBottom: '1px solid #ced4dd',
                    padding: '10px',
                    textAlign: 'center',
                    fontSize: '18px',
                  }}
                >
                  20
                </td>
                <td
                  style={{
                    borderBottom: '1px solid #ced4dd',
                    padding: '10px',
                    textAlign: 'center',
                    fontSize: '18px',
                  }}
                >
                  <button
                    style={{
                      height: '30px',
                      width: '30px',
                      backgroundColor: '#ffffff',
                      border: 'none',
                      cursor: 'pointer',
                    }}
                  >
                    <img src={action} alt="" style={{ height: '20px', width: '20px' }} />
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
          <div
            style={{
              marginTop: '20px',
              display: 'flex',
              justifyContent: 'space-between',
            }}
          >
            <div>
              <h3 style={{ color: '#7F7F7F', fontSize: '18px' }}> Items per page: 10</h3>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50px',
                  border: 'none',
                  backgroundColor: '#f8f8f8',
                }}
              >
                <img
                  src={arrowleft}
                  alt=""
                  style={{
                    fontsize: '30px',
                    width: '30px',
                    height: '30px',
                  }}
                />
              </button>

              <button
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50px',
                  border: 'none',
                  backgroundColor: ' #e5e7eb',
                }}
              >
                1
              </button>

              <button
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50px',
                  border: 'none',
                  backgroundColor: ' #e5e7eb',
                }}
              >
                2
              </button>

              <button
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50px',
                  border: 'none',
                  backgroundColor: ' #e5e7eb',
                }}
              >
                3
              </button>

              <button
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50px',
                  border: 'none',
                  backgroundColor: ' #c1c0e0',
                }}
              >
                4
              </button>

              <button
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50px',
                  border: 'none',
                  backgroundColor: '#f8f8f8',
                }}
              >
                <img
                  src={arrowright}
                  alt=""
                  style={{
                    fontsize: '30px',
                    width: '30px',
                    height: '30px',
                  }}
                />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default Sku_managment_dasboard
F
